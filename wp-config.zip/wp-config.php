<?php
define( 'WP_CACHE', true );

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'goo-api001-dcmatch001' );

/** Database username */
define( 'DB_USER', 'goo-api001-dcmatch001' );

/** Database password */
define( 'DB_PASSWORD', 'lCgPdUBoEYz2dge65i07' );

/** Database hostname */
define( 'DB_HOST', '185.130.44' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '1-f=^4EQuGnTMri_HW?o>7Hg090CA/XCtHam=QM:rr[p5Mm#{*>FYE[<a*]|;:y5' );
define( 'SECURE_AUTH_KEY',  'E$&f*Cdk~-E&WJ3?CSN#}e^+FB(+ Yb UziJ[L5NpZi8.@=BbW>y O|iz>P3+DlZ' );
define( 'LOGGED_IN_KEY',    '^-(uCz7$WI@> Jy#~0!OTKWyLA[VK&^,!3/#Dz}NmRD}5<`vcuR*-YxEGUBZlVS9' );
define( 'NONCE_KEY',        'yy9^U[KwuB8>_s*j*5<ze= U$Lm~D7c-Y|B-#(lD#A5z`c;i$J4$luWMh#GM27}*' );
define( 'AUTH_SALT',        'oJCiRi{y0sb`!tUrKS~q!i:t~n9CF`(h-:LRT<]{&0[;G>xncPx<G0(aWt:gCzpg' );
define( 'SECURE_AUTH_SALT', 'v<J;BK0@rzM%fv,85h@N4;BHm^4v5q3_H*OK;RswR-u&|+5}z^`5X%5bs$-w4k)3' );
define( 'LOGGED_IN_SALT',   'R=B Y#mH#~tOQ9PDAyu(p-@9s]j43m[ATL 9+7Pl{6uENl[CamBZN!v$d@3:N70x' );
define( 'NONCE_SALT',       '>T%m67NXu8YFg,,`v=,l<uxFoB)z4ar2{~rgK/R007iX/EW}fXpRa398>S%5C3K-' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
        define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';